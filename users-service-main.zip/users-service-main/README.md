# Users Service

This is the repository for he Users Service, with provides all the functionality for de sellers and customers for the class work of the subject FIS.